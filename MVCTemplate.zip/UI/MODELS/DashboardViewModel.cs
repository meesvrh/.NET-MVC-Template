﻿using Domain.Models;

namespace $safeprojectname$.Models
{
    public class DashboardViewModel
    {
        public IEnumerable<UserData> Users { get; set; }
    }
}
