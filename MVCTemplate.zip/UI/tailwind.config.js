module.exports = {
    content: ["./Views/**/*.cshtml"],
    darkMode: 'class',
    theme: {
        extend: {},
    },
    variants: {
        extend: {},
    },
    plugins: [],
}
